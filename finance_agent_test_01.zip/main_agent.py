import asyncio
import yaml
import os
import re
from user_functions import FinanceSimulationSkill
from openai import OpenAI

BASE_DIR = r"c:\MS_AI_25\practice\pj\test"
YAML_PATH = os.path.join(BASE_DIR, "skills", "cafe-investment-simulation.yaml")

client = OpenAI(
    base_url="https://fin-test.openai.azure.com/openai/v1",
    api_key="4zFMUflZ8q9uXfMhYpcqVMTAcslme2hrNuMPMCswyXAbT9Z2AyT6JQQJ99CCACYeBjFXJ3w3AAABACOG2gRV"
)

async def call_llm(prompt: str) -> str:
    resp = client.chat.completions.create(
        model="test_model_fin",
        messages=[{"role": "user", "content": prompt}]
    )
    return resp.choices[0].message.content

async def main():
    user_input = input(">>user   : ")

    # YAML 직접 로드
    with open(YAML_PATH, "r", encoding="utf-8") as f:
        workflow = yaml.safe_load(f)

    finance_skill = FinanceSimulationSkill()

    # 1단계: input_to_json
    json_prompt = workflow["stages"][0]["prompt"].replace("{{user_input}}", user_input)
    json_variables = await call_llm(json_prompt)

    # (수정 1) 코드 블록 제거
    clean_json = re.sub(r"^```json\s*|\s*```$", "", json_variables.strip(), flags=re.MULTILINE)

    # JSON → dict 변환
    variables = yaml.safe_load(clean_json)

    # (수정 2) monte_carlo_simulation에 필요한 키만 추출
    sim_keys = ["revenue", "cost", "salary", "hours", "rent", "admin", "fee", "tax_rate"]
    sim_input = {k: variables[k] for k in sim_keys if k in variables}

    # 2단계: run_simulation
    sim_result = finance_skill.monte_carlo_simulation(**sim_input)

    # (수정 3) investment_recovery 단계 추가
    recovery_result = None
    if "initial_investment" in variables:
        recovery_result = finance_skill.investment_recovery(
            initial_investment=variables["initial_investment"],
            avg_profit=sim_result["average_net_profit"]
        )

    # 3단계: explain_result
    explain_prompt = workflow["stages"][2]["prompt"] \
        .replace("{{simulation_result.average_net_profit}}", str(sim_result["average_net_profit"])) \
        .replace("{{simulation_result.loss_probability}}", str(sim_result["loss_probability"]))
    final_explanation = await call_llm(explain_prompt)

    # investment_recovery
    recovery_result = None
    if "initial_investment" in variables:
        recovery_result = finance_skill.investment_recovery(
            initial_investment=variables["initial_investment"],
            avg_profit=sim_result["average_net_profit"]
        )

    # recovery_explanation 정의 (LLM 호출)
    recovery_prompt = workflow["stages"][3]["prompt"] \
        .replace("{{recovery_result.recoverable}}", str(recovery_result["recoverable"])) \
        .replace("{{recovery_result.months}}", str(recovery_result["months"]))
    recovery_explanation = await call_llm(recovery_prompt)



    print("\n>>agent  : ")
    print(final_explanation)

    # (수정) 초기 투자비용이 있을 때만 출력
    if recovery_result and recovery_result.get("recoverable") and recovery_result.get("months") is not None:
        print(recovery_explanation)


if __name__ == "__main__":
    asyncio.run(main())